use strict; use warnings;
package YAML::LibYAML;
our $VERSION = '0.47';

die "YAML::LibYAML has been renamed to YAML::XS. Please use YAML::XS instead.";

1;
